steps to see the working of this project.
1) JaamSim software should be installed
2) open the model.cfg file 
3) the speed of the simulation can be redused by decreasing the time to 2
